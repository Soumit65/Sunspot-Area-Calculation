import numpy as np
import matplotlib.pyplot as plt
from astrolab import imaging as im

def find_spot(array, spot_pos, search=100, print_log=False, fig=None, ax=None):
    if print_log and (fig is None or ax is None):
        fig, ax = plt.subplots()

    inverted_array = np.max(array) - array
    this_spot = im.find_star(inverted_array, star_pos=spot_pos, search=search, print_log=False)

    if print_log:
        r_sun = array.shape[0] // 2
        ax.imshow(array, cmap="Greys_r", origin='lower', extent=[-r_sun, r_sun, -r_sun, r_sun])

        # Convert pixel coordinates to solar-centered coordinates
        x = this_spot[0] - r_sun
        y = this_spot[1] - r_sun

        ax.scatter(0, 0, c='blue', label='Sun center')
        ax.scatter(x, y, facecolor='none', edgecolor='red', label='Sunspot')
        ax.legend()
        plt.show()

    return this_spot
